#!/usr/bin/env python3
"""
Review Training Data Builder

Purpose:
    Build labeled training data (JSONL) from GitHub PR review comments and diffs for:
      - Binary classification: (diff context, comment) -> issue_found? (1/0)
      - Generation (optional): diff context -> gold review comment (only for positives)

Labeling (generic, repo-agnostic):
    - True Positive (label=1): Comment likely caught a real issue, proxied by:
        a) A relevant code change appears near the commented line between base and head, and
        b) The comment text heuristics indicate "issue" (not praise/nit).
      This uses a 40% locality + 60% semantic combined score with thresholds.

    - True Negative (label=0): Otherwise (praise/nit/irrelevant OR no relevant change).

Outputs:
    - classification.jsonl: one row per comment with input features and label.
    - generation.jsonl (optional): positives only, with input (diff context) and target (comment).

Config (config.json keys):
    repo                         str  "owner/repo"
    pr                           int  pull request number
    head_commit                  str  optional; default: PR head
    base_commit                  str  optional; default: PR base
    verbosity                    int  0|1|2

    # Scoring (kept generic and consistent with the evaluator script)
    use_embeddings               bool default true
    embed_model_name             str  default "sentence-transformers/all-MiniLM-L6-v2"
    locality_weight              float/int default 0.40
    semantic_weight              float/int default 0.60
    proximity_full_radius        int  default 8
    proximity_zero_radius        int  default 400
    semantic_focus_delta_threshold float default 0.05
    combined_pass_threshold      float default 0.53  (used as 'relevant change' threshold)

    # Heuristics for "issue-ness" of a comment
    issue_verbs                  [str] override; default built-in
    praise_terms                 [str] override; default built-in

    # Dataset writing
    out_dir                      str  default "./data"
    write_generation             bool default true
    max_comments                 int  optional cap for debugging

Dependencies:
    pip install requests unidiff sentence-transformers

Environment:
    GITHUB_TOKEN (optional; improves rate limits)
"""

from __future__ import annotations

import json
import logging
import math
import os
import re
import sys
from typing import Any, Dict, List, Optional, Tuple

import requests
from unidiff import PatchSet

GITHUB_API = "https://api.github.com"

# ---------- Logging ----------
def setup_logging(verbosity: int) -> None:
    """Configure root logger."""
    level = logging.WARNING
    if verbosity == 1:
        level = logging.INFO
    elif verbosity >= 2:
        level = logging.DEBUG
    logging.basicConfig(level=level, format="%(levelname)s: %(message)s")


# ---------- GitHub helpers ----------
def gh_headers(accept: str = "application/vnd.github+json") -> Dict[str, str]:
    """Build GitHub API headers with optional bearer token."""
    h = {"Accept": accept}
    tok = os.getenv("GITHUB_TOKEN")
    if tok:
        h["Authorization"] = f"Bearer {tok}"
    return h


def gh_get_json(url: str) -> Any:
    """GET a JSON payload from GitHub."""
    r = requests.get(url, headers=gh_headers())
    r.raise_for_status()
    return r.json()


def gh_get_text(url: str, accept: str) -> str:
    """GET a text payload from GitHub with custom Accept header."""
    r = requests.get(url, headers=gh_headers(accept))
    r.raise_for_status()
    return r.text


def list_pr_review_comments(owner: str, repo: str, pr: int) -> List[Dict[str, Any]]:
    """Paginate all review comments on a PR."""
    out: List[Dict[str, Any]] = []
    page = 1
    while True:
        url = f"{GITHUB_API}/repos/{owner}/{repo}/pulls/{pr}/comments?per_page=100&page={page}"
        batch = gh_get_json(url)
        if not batch:
            break
        out.extend(batch)
        page += 1
    return out


def get_pr(owner: str, repo: str, pr: int) -> Dict[str, Any]:
    """Fetch PR metadata (to get base/head SHAs if not provided)."""
    return gh_get_json(f"{GITHUB_API}/repos/{owner}/{repo}/pulls/{pr}")


def get_compare_json(owner: str, repo: str, base: str, head: str) -> Dict[str, Any]:
    """Fetch compare JSON (file list with patches) between two commits."""
    return gh_get_json(f"{GITHUB_API}/repos/{owner}/{repo}/compare/{base}...{head}")


def get_compare_diff(owner: str, repo: str, base: str, head: str) -> str:
    """Fetch raw .diff text for a compare between two commits."""
    return gh_get_text(
        f"{GITHUB_API}/repos/{owner}/{repo}/compare/{base}...{head}",
        accept="application/vnd.github.v3.diff",
    )


def full_diff_text_to_file_patch(diff_text: str, path: str) -> Optional[str]:
    """Extract the diff section for a specific file from a full multi-file diff."""
    marker = f"diff --git a/{path} b/{path}"
    lines = diff_text.splitlines(keepends=True)
    start = None
    for i, line in enumerate(lines):
        if line.startswith(marker):
            start = i
            break
    if start is None:
        return None
    for j in range(start + 1, len(lines)):
        if lines[j].startswith("diff --git a/"):
            return "".join(lines[start:j])
    return "".join(lines[start:])


# ---------- Diff/hunk helpers ----------
def hunk_source_span(h) -> Tuple[int, int]:
    """Return the [start, end] old-file line span (inclusive) covered by this hunk."""
    start = h.source_start
    end = start + h.source_length - 1
    return start, end


def contains_line(h, old_line: int) -> bool:
    """Whether the given old-file line number falls within the hunk's old-file span."""
    s, e = hunk_source_span(h)
    return s <= old_line <= e


def distance_to_span(h, old_line: int) -> int:
    """Distance in lines from the given old-file line to the hunk's old-file span."""
    s, e = hunk_source_span(h)
    if old_line < s:
        return s - old_line
    if old_line > e:
        return old_line - e
    return 0


def nearest_hunk_and_distance(patchset: PatchSet, old_line: int):
    """Find the hunk whose old-file span is nearest to old_line."""
    nearest = None
    best_dist: Optional[int] = None
    for fp in patchset:
        for h in fp:
            d = distance_to_span(h, old_line)
            if best_dist is None or d < best_dist:
                best_dist = d
                nearest = h
    return nearest, (best_dist if best_dist is not None else math.inf)


def min_distance_to_changed_lines(h, original_line: int) -> Optional[int]:
    """Minimum distance (old-file lines) from original_line to any changed line in h."""
    cur_old = h.source_start
    min_d: Optional[int] = None
    for line in h:
        if line.is_removed:
            d = abs(cur_old - original_line)
            min_d = d if min_d is None else min(min_d, d)
            cur_old += 1
        elif line.is_added:
            d = abs(cur_old - original_line)
            min_d = d if min_d is None else min(min_d, d)
        else:
            cur_old += 1
    return min_d


# ---------- Tokenization & similarities ----------
_TOKEN_RE = re.compile(r"[A-Za-z_]\w+|\d+")


def tokenize(s: str) -> List[str]:
    """Extract identifiers and numbers."""
    return _TOKEN_RE.findall(s or "")


def lexical_similarity(a: str, b: str) -> float:
    """Jaccard similarity over token sets (case-insensitive)."""
    ta = set(t.lower() for t in tokenize(a))
    tb = set(t.lower() for t in tokenize(b))
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


# ---------- Embeddings ----------
try:
    from sentence_transformers import SentenceTransformer  # type: ignore

    ST_AVAILABLE = True
except Exception:
    SentenceTransformer = None  # type: ignore
    ST_AVAILABLE = False

_EMBED_MODEL = None


def load_embed_model(name: str):
    """Lazy-load and cache a SentenceTransformers model by name."""
    global _EMBED_MODEL
    if _EMBED_MODEL is not None:
        return _EMBED_MODEL
    if not ST_AVAILABLE:
        logging.info("Embeddings unavailable; using lexical-only scoring.")
        return None
    try:
        logging.info("Use pytorch device_name: cpu")
        logging.info("Load pretrained SentenceTransformer: %s", name)
        _EMBED_MODEL = SentenceTransformer(name)
    except Exception as e:
        logging.warning("Embedding model load failed: %s", e)
        _EMBED_MODEL = None
    return _EMBED_MODEL


def embed_texts(texts: List[str], model) -> List[List[float]]:
    """Encode texts to dense vectors using the provided model."""
    try:
        return model.encode(texts, convert_to_numpy=True).tolist()
    except Exception as e:
        logging.warning("Embedding encode failed: %s", e)
        return [[0.0] * 384 for _ in texts]


def cosine(a: List[float], b: List[float]) -> float:
    """Cosine similarity between two vectors, clamped to [0,1]."""
    if not a or not b:
        return 0.0
    if len(a) != len(b):
        m = min(len(a), len(b))
        a = a[:m]
        b = b[:m]
    num = sum(x * y for x, y in zip(a, b))
    da = math.sqrt(sum(x * x for x in a)) or 1.0
    db = math.sqrt(sum(y * y for y in b)) or 1.0
    return max(0.0, min(1.0, num / (da * db)))


def hybrid_semantic(a: str, b: str, model) -> float:
    """
    Hybrid semantic similarity: 85% embedding cosine + 15% lexical Jaccard.
    If model is None, returns lexical-only similarity.
    """
    if not a.strip() or not b.strip():
        return 0.0
    if model:
        v = embed_texts([a, b], model)
        emb = cosine(v[0], v[1])
        lex = lexical_similarity(a, b)
        return 0.85 * emb + 0.15 * lex
    return lexical_similarity(a, b)


# ---------- Scoring ----------
def locality_score_from_distance(dist: int, full_radius: int, zero_radius: int) -> float:
    """Map a line distance to a locality score with linear decay."""
    if dist <= full_radius:
        return 1.0
    if dist >= zero_radius:
        return 0.0
    return max(0.0, 1.0 - (dist - full_radius) / max(1.0, (zero_radius - full_radius)))


def evaluate_followup_relevance(
    comment_body: str,
    patchset: PatchSet,
    original_line: int,
    cfg: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Compute whether the changes between base and head are relevant to the comment.

    Returns:
        dict with locality_score, semantic_score, combined_score and internals.
    """
    use_embeddings = bool(cfg.get("use_embeddings", True))
    model_name = cfg.get("embed_model_name", "sentence-transformers/all-MiniLM-L6-v2")
    model = load_embed_model(model_name) if use_embeddings else None

    # Select hunk containing original_line; else nearest
    target_hunk = None
    dist_to_span = None
    for fp in patchset:
        for h in fp:
            if contains_line(h, original_line):
                target_hunk = h
                dist_to_span = 0
                break
        if target_hunk:
            break
    if target_hunk is None:
        target_hunk, dist_to_span = nearest_hunk_and_distance(patchset, original_line)
    if target_hunk is None:
        # File not changed
        return {
            "locality_score": 0.0,
            "semantic_score": 0.0,
            "combined_score": 0.0,
            "sim_removed": 0.0,
            "sim_added": 0.0,
            "sim_local": 0.0,
            "focus_delta": 0.0,
            "min_line_distance": None,
            "dist_to_hunk_span": None,
        }

    removed_lines, added_lines = [], []
    cur_old = target_hunk.source_start
    for line in target_hunk:
        if line.is_removed:
            removed_lines.append(line.value.rstrip("\n"))
            cur_old += 1
        elif line.is_added:
            added_lines.append(line.value.rstrip("\n"))
        else:
            cur_old += 1

    removed_block = "\n".join(removed_lines)
    added_block = "\n".join(added_lines)
    local_block = (removed_block + "\n" + added_block).strip()

    # Locality
    min_line_distance = min_distance_to_changed_lines(target_hunk, original_line)
    if min_line_distance is None:
        min_line_distance = dist_to_span if dist_to_span is not None else 10**9
    full_r = int(cfg.get("proximity_full_radius", 8))
    zero_r = int(cfg.get("proximity_zero_radius", 400))
    locality = locality_score_from_distance(min_line_distance, full_r, zero_r)

    # Semantics (hybrid)
    sim_removed = hybrid_semantic(comment_body, removed_block, model) if removed_block else 0.0
    sim_added = hybrid_semantic(comment_body, added_block, model) if added_block else 0.0
    sim_local = hybrid_semantic(comment_body, local_block, model) if local_block else 0.0
    focus_delta = sim_added - sim_removed
    if focus_delta <= 0:
        focus_component = 0.0
    else:
        d = float(cfg.get("semantic_focus_delta_threshold", 0.05))
        denom = max(1e-9, 2 * d)
        focus_component = max(0.0, min(1.0, focus_delta / denom))
    semantic = 0.5 * sim_added + 0.3 * sim_local + 0.2 * focus_component

    # Combine 40/60
    w_loc = float(cfg.get("locality_weight", 0.40))
    w_sem = float(cfg.get("semantic_weight", 0.60))
    s = w_loc + w_sem
    if s <= 0:
        w_loc, w_sem = 0.40, 0.60
        s = 1.0
    w_loc, w_sem = w_loc / s, w_sem / s
    combined = w_loc * locality + w_sem * semantic

    return {
        "locality_score": locality,
        "semantic_score": semantic,
        "combined_score": combined,
        "sim_removed": sim_removed,
        "sim_added": sim_added,
        "sim_local": sim_local,
        "focus_delta": focus_delta,
        "min_line_distance": min_line_distance,
        "dist_to_hunk_span": dist_to_span,
        "removed_block": removed_block,
        "added_block": added_block,
        "local_block": local_block,
    }


# ---------- Heuristics: issue vs praise ----------
DEFAULT_ISSUE_VERBS = [
    "fix",
    "wrong",
    "incorrect",
    "should",
    "must",
    "bug",
    "security",
    "vuln",
    "avoid",
    "remove",
    "deny",
    "error",
    "fail",
    "unsafe",
    "leak",
    "broken",
    "not",
]
DEFAULT_PRAISE_TERMS = ["lgtm", "nice", "great", "thanks", "nit", "nitpick", "typo", "style"]


def is_issue_like_comment(body: str, issue_verbs: List[str], praise_terms: List[str]) -> bool:
    """
    Heuristic: classify a review comment as "issue-like" (not praise/nit).

    Returns:
        True if likely requesting a change due to a problem; False otherwise.
    """
    text = (body or "").lower()
    if any(t in text for t in praise_terms):
        return False
    return any(v in text for v in issue_verbs)


# ---------- Assembly ----------
def build_example(
    owner: str,
    repo: str,
    comment: Dict[str, Any],
    base_sha: str,
    head_sha: str,
    cfg: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    """
    Build one labeled example from a single review comment.

    Returns:
        Example dict or None if the file/diff could not be processed.
    """
    path = comment.get("path")
    original_line = comment.get("original_line")
    comment_body = comment.get("body") or ""
    if not path or original_line is None:
        return None

    cmp_json = get_compare_json(owner, repo, base_sha, head_sha)
    cmp_file = next((f for f in cmp_json.get("files", []) if f.get("filename") == path), None)

    if cmp_file and cmp_file.get("patch"):
        file_patch_text = f"--- a/{path}\n+++ b/{path}\n{cmp_file['patch']}"
    else:
        raw = get_compare_diff(owner, repo, base_sha, head_sha)
        extracted = full_diff_text_to_file_patch(raw, path)
        file_patch_text = extracted or ""

    patchset = PatchSet.from_string(file_patch_text)

    scores = evaluate_followup_relevance(comment_body, patchset, original_line, cfg)

    combined = scores["combined_score"]
    pass_thr = float(cfg.get("combined_pass_threshold", 0.53))
    relevant_change = combined >= pass_thr

    issue_verbs = cfg.get("issue_verbs") or DEFAULT_ISSUE_VERBS
    praise_terms = cfg.get("praise_terms") or DEFAULT_PRAISE_TERMS
    issue_like = is_issue_like_comment(comment_body, issue_verbs, praise_terms)

    label = 1 if (issue_like and relevant_change) else 0

    # Build compact diff context (added/removed around line)
    context = {
        "file": path,
        "removed_block": scores.get("removed_block", ""),
        "added_block": scores.get("added_block", ""),
        "local_block": scores.get("local_block", ""),
        "min_line_distance": scores.get("min_line_distance"),
    }

    return {
        "repo": f"{owner}/{repo}",
        "pr": comment.get("pull_request_url", "").split("/")[-1] or None,
        "comment_id": comment.get("id"),
        "comment_body": comment_body,
        "original_line": original_line,
        "base_sha": base_sha,
        "head_sha": head_sha,
        "label": label,  # 1=true positive, 0=true negative
        "scores": {
            "locality": round(scores["locality_score"], 4),
            "semantic": round(scores["semantic_score"], 4),
            "combined": round(combined, 4),
            "sim_removed": round(scores["sim_removed"], 4),
            "sim_added": round(scores["sim_added"], 4),
            "sim_local": round(scores["sim_local"], 4),
            "focus_delta": round(scores["focus_delta"], 4),
        },
        "context": context,
    }


def write_jsonl(path: str, rows: List[Dict[str, Any]]) -> None:
    """Write a list of dicts to JSONL."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def load_config(path: str) -> Dict[str, Any]:
    """Load a JSON configuration file."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def run() -> None:
    """
    Entry point: build dataset from PR review comments.

    Steps:
        - Resolve base/head SHAs (from PR or config).
        - List PR review comments.
        - For each comment, compute relevance (locality+semantic) and label.
        - Write classification.jsonl (all examples).
        - Optionally write generation.jsonl (positives only).
    """
    cfg = load_config(os.path.join(os.getcwd(), "config.json"))
    setup_logging(int(cfg.get("verbosity", 0)))

    repo_full = cfg.get("repo", "")
    if "/" not in repo_full:
        raise RuntimeError("config.repo must be 'owner/repo'")
    owner, repo = repo_full.split("/", 1)

    pr_num = int(cfg.get("pr", 0))
    if pr_num <= 0:
        raise RuntimeError("config.pr (pull request number) is required")

    pr = get_pr(owner, repo, pr_num)
    base_sha = cfg.get("base_commit") or pr.get("base", {}).get("sha")
    head_sha = cfg.get("head_commit") or pr.get("head", {}).get("sha")
    if not base_sha or not head_sha:
        raise RuntimeError("Unable to resolve base/head SHAs")

    comments = list_pr_review_comments(owner, repo, pr_num)
    max_comments = cfg.get("max_comments")
    if isinstance(max_comments, int) and max_comments > 0:
        comments = comments[:max_comments]

    logging.info("Building dataset from %d comments (base=%s..head=%s)", len(comments), base_sha[:7], head_sha[:7])

    examples: List[Dict[str, Any]] = []
    for c in comments:
        try:
            ex = build_example(owner, repo, c, base_sha, head_sha, cfg)
            if ex:
                examples.append(ex)
        except requests.HTTPError as e:
            logging.warning("Skip comment %s due to HTTP error: %s", c.get("id"), e)
        except Exception as e:
            logging.warning("Skip comment %s due to error: %s", c.get("id"), e)

    out_dir = cfg.get("out_dir", "./data")
    os.makedirs(out_dir, exist_ok=True)

    # Write classification dataset
    cls_rows: List[Dict[str, Any]] = []
    for ex in examples:
        cls_rows.append(
            {
                "repo": ex["repo"],
                "pr": ex["pr"],
                "comment_id": ex["comment_id"],
                "label": ex["label"],
                "input": {
                    "diff_context": ex["context"]["local_block"],
                    "file": ex["context"]["file"],
                    "added_block": ex["context"]["added_block"],
                    "removed_block": ex["context"]["removed_block"],
                    "comment": ex["comment_body"],
                },
                "meta": {
                    "scores": ex["scores"],
                    "base_sha": ex["base_sha"],
                    "head_sha": ex["head_sha"],
                    "original_line": ex["original_line"],
                },
            }
        )
    write_jsonl(os.path.join(out_dir, "classification.jsonl"), cls_rows)

    # Optionally write generation dataset (positives only)
    if bool(cfg.get("write_generation", True)):
        gen_rows: List[Dict[str, Any]] = []
        for ex in examples:
            if ex["label"] == 1 and ex["comment_body"].strip():
                gen_rows.append(
                    {
                        "repo": ex["repo"],
                        "pr": ex["pr"],
                        "comment_id": ex["comment_id"],
                        "input": {
                            "diff_context": ex["context"]["local_block"],
                            "file": ex["context"]["file"],
                            "added_block": ex["context"]["added_block"],
                            "removed_block": ex["context"]["removed_block"],
                        },
                        "target": ex["comment_body"],
                        "meta": {
                            "scores": ex["scores"],
                            "base_sha": ex["base_sha"],
                            "head_sha": ex["head_sha"],
                            "original_line": ex["original_line"],
                        },
                    }
                )
        write_jsonl(os.path.join(out_dir, "generation.jsonl"), gen_rows)

    logging.info("Wrote %d classification and %d generation examples to %s", len(cls_rows), len([r for r in examples if r['label']==1]), out_dir)


if __name__ == "__main__":
    try:
        run()
    except requests.HTTPError as e:
        logging.error("HTTP error: %s", e)
        if e.response is not None:
            logging.error("Response snippet: %s", e.response.text[:600])
        sys.exit(1)
    except Exception as e:
        logging.exception("Unhandled error: %s", e)
        sys.exit(1)